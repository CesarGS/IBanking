<?php 
	require_once "conexion.php";
    $conexion=conexion();
    $idprestamo=$_POST['idprestamo'];
    $idcliente=$_POST['idcliente'];
    $monto=$_POST['monto'];
    $cuota=$_POST['cuota'];
    $tiempo=$_POST['tiempo'];


	$sql="UPDATE prestamos set idcliente='$idcliente',
                               monto='$monto',
                               cuota='$cuota',
                               tiempo='$tiempo'

				where idprestamo='$idprestamo'";
	echo $result=mysqli_query($conexion,$sql);

 ?>