<?php 

	require_once "conexion.php";
	$conexion=conexion();
	$n=$_POST['nombre'];
	$a=$_POST['apellido'];
	$t=$_POST['telefono'];

	$sql="INSERT into clientes (nombre,apellido,telefono)
								values ('$n','$a','$t')";
	echo $result=mysqli_query($conexion,$sql);

 ?>