

<?php 
		function conexion(){

		
			$conexion=mysqli_connect("localhost:3306", "root", "", "banking");

			return $conexion;
		}

 ?>