<?php 
	require_once "conexion.php";
	$conexion=conexion();
	$idprestamo=$_POST['idprestamo'];

	$sql="DELETE from prestamos where idprestamo='$idprestamo'";
	echo $result=mysqli_query($conexion,$sql);
 ?>