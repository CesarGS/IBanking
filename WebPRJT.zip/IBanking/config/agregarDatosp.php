<?php 

	require_once "conexion.php";
    $conexion=conexion();
    
	$idcliente=$_POST['idcliente'];
    $monto=$_POST['monto'];
    $cuota=$_POST['cuota'];
    $tiempo=$_POST['tiempo'];


	$sql="INSERT into prestamos (idcliente,monto,cuota,tiempo)
                                values ('$idcliente','$monto','$cuota','$tiempo')";
                                
  echo $result=mysqli_query($conexion,$sql);

   ?>