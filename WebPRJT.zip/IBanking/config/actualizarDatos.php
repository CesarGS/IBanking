<?php 
	require_once "conexion.php";
	$conexion=conexion();
	$id=$_POST['idcliente'];
	$n=$_POST['nombre'];
	$a=$_POST['apellido'];
	$t=$_POST['telefono'];

	$sql="UPDATE  clientes set nombre='$n',
								apellido='$a',
								telefono='$t'
				where idcliente='$id'";
	echo $result=mysqli_query($conexion,$sql);

 ?>