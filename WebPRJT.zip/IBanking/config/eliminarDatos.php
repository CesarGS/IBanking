
<?php 
	require_once "conexion.php";
	$conexion=conexion();
	$idcliente=$_POST['idcliente'];

	$sql="DELETE from clientes where idcliente='$idcliente'";
	echo $result=mysqli_query($conexion,$sql);
 ?>