function agregardatosp(  idcliente,monto,cuota,tiempo ){

	cadenap="idcliente=" + idcliente +
			 "&monto=" + monto+
			 "&cuota="+cuota+
			 "&tiempo="+tiempo;
$.ajax({
 type:"POST",
 url:"config/agregarDatosp.php",
 data:cadenap,
 success:function(y){
	 if(y==1){
		 $('#prest').load('prestamo.php');
		 alertify.success("agregado con exito :)");
	 }else{
		 alertify.error("Fallo el servidor :(");
	 }
 }
});

}  
function agregaformp(datosp){

dp=datosp.split('||');
$('#idprestamoE').val(dp[0]);
$('#idclienteE').val(dp[1]);
$('#montoE').val(dp[2]);
$('#cuotaE').val(dp[3]);
$('#tiempoE').val(dp[4]);

}

function actualizarDatosp(){

idprestamo=$('#idprestamoE').val();
idcliente=$('#idclienteE').val();
monto=$('#montoE').val();
cuota=$('#cuotaE').val();
tiempo=$('#tiempoE').val();

cadenap= "idprestamo="+idprestamo +
	 "&idcliente=" + idcliente +
	 "&monto=" + monto + 
	 "&cuota=" + cuota +
	 "&tiempo=" +tiempo;

	 $.ajax({
		 type:"POST",
		 url:"config/actualizarDatosp.php",
		 data:cadenap,
		 success:function(y){
			 if(y==1){
				 $('#prest').load('prestamo.php');
				 alertify.success("actualizado con exito :)");
			 }else{
				 alertify.error("Fallo el servidor :(");
			 }
		 }
	 });
 
 }  
 function preguntarE(idprestamo){
	 alertify.confirm('Eliminar prestamo', '¿Esta seguro de eliminar este prestamo?', 
					 function(){ eliminarDatosp(idprestamo) }
				   , function(){ alertify.error('Se cancelo')});
 }
 function eliminarDatosp(idprestamo){
 
	 cadenap="idprestamo=" + idprestamo;
 
		 $.ajax({
			 type:"POST",
			 url:"config/eliminarDatosp.php",
			 data:cadenap,
			 success:function(y){
				 if(y==1){
					 $('#prest').load('prestamo.php');
					 alertify.success("Eliminado con exito!");
				 }else{
					 alertify.error("Fallo el servidor :(");
				 }
			 }
		 });
 }