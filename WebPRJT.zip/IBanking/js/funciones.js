

function agregardatos(nombre,apellido,telefono){

	cadena=  "nombre=" + nombre + 
			"&apellido=" + apellido +
			"&telefono=" + telefono;

	$.ajax({
		type:"POST",
		url:"config/agregarDatos.php",
		data:cadena,
		success:function(r){
			if(r==1){
                $('#cliente').load('cliente.php');
				alertify.success("agregado con exito :)");
			}else{
				alertify.error("Fallo el servidor :(");
			}
		}
	});

}
function agregaform(datos){

	d=datos.split('||');

	$('#idcliente').val(d[0]);
	  $('#nombreE').val(d[1]);
	$('#apellidoE').val(d[2]);
	$('#telefonoE').val(d[3]);
	
}
function actualizarDatos(){


	idcliente=$('#idcliente').val();
	nombre=$('#nombreE').val();
	apellido=$('#apellidoE').val();
	telefono=$('#telefonoE').val();

	cadena= "idcliente=" + idcliente +
			"&nombre=" + nombre + 
			"&apellido=" + apellido +
			"&telefono=" + telefono;

	$.ajax({
		type:"POST",
		url:"config/actualizarDatos.php",
		data:cadena,
		success:function(r){
			
			if(r==1){
				$('#cliente').load('cliente.php');
				alertify.success("Actualizado con exito :)");
			}else{
				alertify.error("Fallo el servidor :(");
			}
		}
	});

}
function preguntarSiNo(idcliente){
	alertify.confirm('Eliminar Cliente', '¿Esta seguro de eliminar este cliente?', 
					function(){ eliminarDatos(idcliente) }
                  , function(){ alertify.error('Se cancelo')});
}
function eliminarDatos(idcliente){

	cadena="idcliente=" + idcliente;

		$.ajax({
			type:"POST",
			url:"config/eliminarDatos.php",
			data:cadena,
			success:function(r){
				if(r==1){
					$('#cliente').load('cliente.php');
					alertify.success("Eliminado con exito!");
				}else{
					alertify.error("Fallo el servidor :(");
				}
			}
		});
}
