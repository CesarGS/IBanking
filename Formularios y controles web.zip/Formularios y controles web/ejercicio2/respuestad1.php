<html>
<head>
<title>respuestackb</title></head>
</head>
<body>
<?php

$total = 0;
$nombre= $_REQUEST['nombre'];

if(isset($_REQUEST['deporte1'])){
	$total++;

}
if(isset($_REQUEST['deporte2'])){
	$total++;

}
if(isset($_REQUEST['deporte3'])){
	$total++;

}
if(isset($_REQUEST['deporte4'])){
	$total++;

}

echo "$nombre realiza $total deportes."


?>

</body>


</html>