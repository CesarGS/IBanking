<html>
<head>	
<title> series de deportes </title>
<body>
<form method = "post" action = "respuestad1.php" >
</br>
 Introdusca el nombre: 

<input type = "text" name = "nombre">
</br>
seleccione el deporte:
</br>
<input type = "checkbox" name = "deporte1" > voley
</br>
<input type = "checkbox" name = "deporte2" > basket
</br>
<input type = "checkbox" name = "deporte3" > tennis
</br>
<input type = "checkbox" name = "deporte4" > futbol
</br>
<input type = "submit" value = "Aceptar">


</body>


</head>