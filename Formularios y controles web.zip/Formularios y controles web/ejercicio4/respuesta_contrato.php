<html>
<head>
<title>respuesta de contrato </title></head>
</head>
<body>
<?php
echo $_REQUEST ['copl_contrato'];


?>

</body>
</html>