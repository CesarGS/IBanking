<html>
<head>	
<title> contrato </title>
<body>
<form method = "post" action = "respuesta_contrato.php" >
</br>
realize el contrato : 

</br>
<textarea name="copl_contrato" rows="9" cols="90">
	
En la ciudad de [........], se acuerda entre la Empresa [..........]
representada por el Sr. [..............] en su carácter de Apoderado,
con domicilio en la calle [..............] y el Sr. [..............],
futuro empleado con domicilio en [..............], celebrar el presente
contrato a Plazo Fijo, de acuerdo a la normativa vigente de los
artículos 90,92,93,94, 95 y concordantes de la Ley de Contrato de Trabajo N° 20.744.
</textarea>

</br>
<input type = "submit" value = "Aceptar">
</form>

</body>


</head>