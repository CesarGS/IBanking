<html>
<head>
<title>respuesta de ingresos </title></head>
</head>
<body>
<?php

$nombre= $_REQUEST['nombre'];
if( $_REQUEST['ingresos_mesual'] ==3){
	
	echo "$nombre debe de realizar su pago de impuesto";
}else{
	
	echo "$nombre no tiene que pagar impuestos";
}


?>

</body>
</html>