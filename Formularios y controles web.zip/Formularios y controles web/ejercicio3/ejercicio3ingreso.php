<html>
<head>	
<title> ingresos </title>
<body>
<form method = "post" action = "respuesta_ingreso.php" >
</br>
 Introdusca el nombre: 
</br>
<input type = "text" name = "nombre">
</br>
seleccione la categoria de su ingreso mensual:
</br>
<select name="ingresos_mesual">
	<option value="1" > 1-100 </option>
	<option value="2" > 101-3000 </option>
	<option value="3" > 3000 </option>

</select>

</br>
<input type = "submit" value = "Aceptar">


</body>


</head>