<html>
<head>	
<title> encuesta </title>
<body>
<form method = "post" action = "femenino1.php" >
</br>
 Introdusca el nombre: 

<input type = "text" name = "nombre">
</br>
femenino:
<input type = "radio" name = "rad_fm" value = "femenino">

</br>
masculino:
<input type = "radio" name = "rad_fm" value="masculino">
</br>
<h1> formulario  femenino </h1>
elige un color favorito (femenino):
</br>
rosado
<input type = "radio" name = "radio2" value = "rosado" >
</br>
amarillo
<input type = "radio" name = "radio2" value = "amarillo">
</br>
morado
<input type = "radio" name = "radio2"value = "morado" >
</br>
elige una marca de ropa favorita  (femenino):
</br>
zara
<input type = "radio" name = "radio3" value = "zara" >
</br>
praga
<input type = "radio" name = "radio3" value = "praga">
</br>
louis vuitton
<input type = "radio" name = "radio3"value = "louis vuitton" >

</br>

elige tipo de pelo favorito   (femenino):
</br>
riso
<input type = "radio" name = "radio4" value = "riso" >
</br>
lacio
<input type = "radio" name = "radio4" value = "lacio">
</br>

elige tipo de calzado favorito  (femenino):
</br>
cerrados
<input type = "radio" name = "radio5" value = "cerrados">
</br>
abierto
<input type = "radio" name = "radio5" value = "abierto">
</br>
altos
<input type = "radio" name = "radio5" value = "altos">
</br>
bajitos
<input type = "radio" name = "radio5" value = "bajitos">
</br>
<h1> formulario  masculino </h1>
elige tipo de color favorito   (masculino):
</br>
azul
<input type = "radio" name = "radio6" value = "azul">
</br>
verde
<input type = "radio" name = "radio6" value = "verde">
</br>
negro
<input type = "radio" name = "radio6" value = "negro">
</br>
elige marca de ropa favorita   (masculino):
</br>
reebok
<input type = "radio" name = "radio7" value = "reebok">
</br>
timberlad
<input type = "radio" name = "radio7" value = "timberlad">
</br>
nike
<input type = "radio" name = "radio7" value = "nike">
</br>
elige tipo de pelo favorito   (masculino):
</br>
largo
<input type = "radio" name = "radio8" value = "largo">
</br>
corto
<input type = "radio" name = "radio8" value = "corto">
</br>
elige tipo de calzado favorito(masculino):
</br>
deportivo
<input type = "radio" name = "radio9" value = "deportivo">
</br>
casual
<input type = "radio" name = "radio9" value = "casual">
</br>
formales
<input type = "radio" name = "radio9" value = "formales">
</br>
sandalias
<input type = "radio" name = "radio9" value = "sandalias">
</br>

<input type = "submit" value = "Aceptar">


</body>


</head>