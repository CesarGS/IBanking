<html>
<head>
<title>respuesta</title></head>
</head>
<body>
<?php


if(isset($_REQUEST['radio2'] )){	
	 echo "<h1> respuesra del frmulario femenino </h1>";
	 echo "</br>";
	  echo "su nombre es :</br>";
	echo $_REQUEST['nombre'];
	echo "</br>";
	echo "su genero es :</br>";
	echo $_REQUEST['rad_fm'];
	echo "</br>";
	echo "su color favorito  es : </br>";
	echo  $_REQUEST['radio2'];
	echo "</br>";
	echo "su ropa favorita  es </br>";
    echo $_REQUEST['radio3'];
    echo "</br>";
    echo "su tipo de pelo favorito es: </br>";
	echo $_REQUEST['radio4'] ;
	echo "</br>";
	echo "su tipo de calzado favorito es: </br>";
	echo $_REQUEST['radio5'];

}

if(isset($_REQUEST['radio6'])){
    echo "<h1> Respuesta del formulario masculino </h1>";
    echo "</br>";
    echo "su nombre es:</br>";
    echo $_REQUEST['nombre'];
    echo "</br>";
    echo "su genero es : </br>";
	 echo $_REQUEST['rad_fm'];
	 echo "</br>";
	 echo "su color favorito es: </br>";
     echo $_REQUEST['radio6'];
     echo "</br>";
     echo "su ropa favorita es: </br>";
	 echo $_REQUEST['radio7'];
	 echo "</br>";
	 echo "su tipo de pelo favorito es: </br>";
	 echo $_REQUEST['radio8'];
	 echo "</br>";
	 echo "su tipo de calzado favorito es: </br>";
	 echo $_REQUEST['radio9'];


}


?>

</body>


</html>